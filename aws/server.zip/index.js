require('source-map-support').install();
const express = require('aws-serverless-express');
const app_import = require('./dist/app');
const app = app_import.configureApp();
const server = express.createServer(app, undefined, []);
exports.handler = (event, context) => express.proxy(server, event, context);
