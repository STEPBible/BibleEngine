"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const request = require("supertest");
const app_1 = require("../src/app");
describe('a feature of the system', () => {
    it('displays some specific behaviour', async () => {
        const app = app_1.configureApp();
        const response = await request(app).get('/');
        expect(response).toMatchObject({
            status: 200,
            text: '<!DOCTYPE html><html><head><title>Serverless Express Typescript Starter Kit</title></head><body><h1>Serverless Express Typescript Starter Kit</h1><p>Hello world!</p></body></html>'
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhhbXBsZS50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZXhhbXBsZS50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscUNBQXFDO0FBQ3JDLG9DQUEwQztBQUUxQyxRQUFRLENBQUMseUJBQXlCLEVBQUUsR0FBRyxFQUFFO0lBQ3JDLEVBQUUsQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLElBQUksRUFBRTtRQUM5QyxNQUFNLEdBQUcsR0FBRyxrQkFBWSxFQUFFLENBQUM7UUFDM0IsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFDM0IsTUFBTSxFQUFFLEdBQUc7WUFDWCxJQUFJLEVBQ0EscUxBQXFMO1NBQzVMLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMifQ==